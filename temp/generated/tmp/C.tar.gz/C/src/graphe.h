#ifndef GRAPHEH
#define GRAPHEH

#include <stdio.h>
#include <stdlib.h>

#include "param.h"

int exist(int a, int b);

void add(int a, int b);

void rem(int a, int b);

#endif
